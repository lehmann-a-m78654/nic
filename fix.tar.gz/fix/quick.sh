cd build
make
cd ..
cp build/logread logread
cp build/logappend logappend